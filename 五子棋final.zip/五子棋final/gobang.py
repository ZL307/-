import pygame
from pygame.locals import *
import sys
import win32ui

pygame.init()
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
background = (201, 202, 187)
checkerboard = (80, 80, 80)
button = (52, 53, 44)
# 音乐
play_chess_sound = pygame.mixer.Sound("music/play_chess.wav")
play_chess_sound.set_volume(0.2)
button_sound = pygame.mixer.Sound("music/button.wav")
button_sound.set_volume(0.2)
victor_sound = pygame.mixer.Sound("music/victory.wav")
victor_sound.set_volume(0.2)
pygame.display.set_caption('砖业五子棋')


def draw_chessboard(screen):
    """绘制棋盘
    大小为15*15和一些功能按钮。
    """
    global background, checkerboard, button
    # 画棋盘
    for i in range(15):
        pygame.draw.line(screen, BLACK, (40 * i + 30, 30), (40 * i + 30, 590))
        pygame.draw.line(screen, BLACK, (30, 40 * i + 30), (590, 40 * i + 30))
    # 画边界
    pygame.draw.line(screen, BLACK, (2, 2), (2, 622), 4)
    pygame.draw.line(screen, BLACK, (622, 2), (622, 622), 4)
    pygame.draw.line(screen, BLACK, (2, 2), (622, 2), 4)
    pygame.draw.line(screen, BLACK, (2, 622), (622, 622), 4)
    # 画棋盘的定位点
    pygame.draw.circle(screen, checkerboard, (150, 150), 6)
    pygame.draw.circle(screen, checkerboard, (470, 150), 6)
    pygame.draw.circle(screen, checkerboard, (150, 470), 6)
    pygame.draw.circle(screen, checkerboard, (470, 470), 6)
    pygame.draw.circle(screen, checkerboard, (310, 310), 6)
    # 矩形参数由四个值构成的元组，分别是矩形左上角的x、y坐标，矩形的宽和高
    pygame.draw.rect(screen, button, [640, 10, 140, 50], 5)
    pygame.draw.rect(screen, button, [640, 70, 140, 50], 5)
    pygame.draw.rect(screen, button, [640, 440, 80, 50], 5)
    pygame.draw.rect(screen, button, [640, 500, 140, 50], 5)
    pygame.draw.rect(screen, button, [640, 560, 140, 50], 5)
    pygame.draw.rect(screen, button, [640, 230, 140, 50], 5)
    pygame.draw.rect(screen, button, [640, 295, 60, 30], 3)
    pygame.draw.rect(screen, button, [720, 295, 60, 30], 3)

    s_font = pygame.font.Font('font1.ttf', 30)
    d_font = pygame.font.Font('font1.ttf', 20)
    text1 = s_font.render("人人对战", True, button)
    text2 = s_font.render("人机对战", True, button)
    text3 = s_font.render("悔棋", True, button)
    text4 = s_font.render("重新开始", True, button)
    text5 = s_font.render("退出游戏", True, button)
    text6 = s_font.render("载入棋谱", True, button)
    text7 = d_font.render("前一步", True, button)
    text8 = d_font.render("后一步", True, button)
    screen.blit(text1, (650, 20))
    screen.blit(text2, (650, 80))
    screen.blit(text3, (650, 450))
    screen.blit(text4, (650, 510))
    screen.blit(text5, (650, 570))
    screen.blit(text6, (650, 240))
    screen.blit(text7, (640, 300))
    screen.blit(text8, (720, 300))


def draw_chessman(x, y, screen, color):
    """画棋子，当color = 0画黑子，color = 1时画白子

    """
    if color == 0:
        black_chessman = pygame.image.load('./wuziqi/Black_chess.png')
        screen.blit(black_chessman, ((x - 4) * 40 + 15, (y - 4) * 40 + 15))
    elif color == 1:
        white_chessman = pygame.image.load('./wuziqi/White_chess.png')
        screen.blit(white_chessman, ((x - 4) * 40 + 15, (y - 4) * 40 + 15))


def draw_chessboard_with_chessman(chesslist, screen):
    screen.fill(background)
    screen.blit(background_jpg, (0, 0))
    draw_chessboard(screen)
    for i in range(4, 19):
        for j in range(4, 19):
                draw_chessman(i, j, screen, chesslist[i][j])


def choose_save(screen, chesslist, chessindex, index):
    pygame.draw.rect(screen, button, [640, 340, 140, 50], 5)
    s_font = pygame.font.Font('font1.ttf', 30)
    text = s_font.render("保存棋谱", True, button)
    screen.blit(text, (650, 350))
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    x, y = event.pos[0], event.pos[1]
                    if 650 < x < 790 and 350 < y < 380:
                        try:
                            save_chess(chesslist, chessindex, index)
                        except:
                            print("Save Failed！")
                        else:
                            print("Save Succeeded!")
                    choose_button(x, y)


def choose_turn(screen):
    """
    选择人机先手还是玩家先手
    :return:
    """
    pygame.draw.rect(screen, button, [640, 130, 100, 30], 3)
    pygame.draw.rect(screen, button, [640, 170, 100, 30], 3)
    s_font = pygame.font.Font('font1.ttf', 25)
    text1 = s_font.render("电脑先手", True, button)
    text2 = s_font.render("玩家先手", True, button)
    screen.blit(text1, (640, 130))
    screen.blit(text2, (640, 170))
    pygame.display.update()
    while True:
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    x, y = event.pos[0], event.pos[1]
                    if 640 < x < 740 and 130 < y < 160:
                        return 1
                    elif 640 < x < 740 and 170 < y < 200:
                        return 0
                    choose_button(x, y)


def choose_mode():
    """选择人人对战还是人机对战还是载入棋谱

    """
    mode = 1
    load = False
    while True:
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    x, y = event.pos[0], event.pos[1]
                    # 如果点击人人对战
                    if 650 < x < 790 and 10 < y < 60:
                        mode = 1
                        return mode, load
                    elif 650 < x < 790 and 70 < y < 120:
                        mode = 0
                        return mode, load
                    elif 640 < x < 780 and 230 < y < 280:
                        load = True
                        return mode, load
                    choose_button(x, y)


def choose_button(x, y):
    """功能键：退出游戏和重新开始
    """
    # 如果点击‘重新开始’
    if 650 < x < 790 and 500 < y < 550:
        button_sound.play(0)
        main()

    elif 650 < x < 790 and 560 < y < 610:
        button_sound.play(0)
        pygame.quit()
        sys.exit()


def save_chess(chesslist, chessindex, index):
    dlg = win32ui.CreateFileDialog(0)
    dlg.SetOFNInitialDir(r"C:\Users\lenovo\Desktop")
    flag = dlg.DoModal()
    filename = dlg.GetPathName()
    if flag == 1:
        print("Save as", filename)
    else:
        print("Save Failed!")
    for i in range(23):
        for j in range(23):
            chesslist[i][j] = str(chesslist[i][j])
            chessindex[i][j] = str(chessindex[i][j])
    str1 = ''
    str2 = ''
    for i in range(23):
        if i == 0:
            str1 = ','.join(chesslist[i])
        str1 = str1 + '\n' + ','.join(chesslist[i])
        str2 = str2 + '\n' + ','.join(chessindex[i])
    f = open(filename, 'w+')
    f.write(str1)
    f.write(str2)
    f.write('\n' + str(index))
    f.close()


def load_chess():
    dlg = win32ui.CreateFileDialog(1)  # 1表示打开文件对话框
    dlg.SetOFNInitialDir(r"C:\Users\lenovo\Desktop")  # 设置打开文件对话框中的初始显示目录
    flag = dlg.DoModal()
    filename = dlg.GetPathName()  # 获取选择的文件名称
    if flag == 1:
        print("Open", filename)
    else:
        print("Open Failed!")
    lst_tmp = []
    f = open(filename, 'r')
    for line in f.readlines():
        line = line.strip('\n')
        xt = [i for i in line.split(',')]
        lst_tmp.append(xt)
    c_list = lst_tmp[0: 23]
    c_index = lst_tmp[23: 46]
    index_max = lst_tmp[47][0]
    f.close()
    chessmap = [[['N' for _ in range(23)] for _ in range(23)] for _ in range(int(index_max))]
    for i in range(4, 19):
        for j in range(4, 19):
            if c_list[i][j] != 'Y' and c_list[i][j] != 'N':
                c_list[i][j] = int(c_list[i][j])
            if c_index[i][j] != 'Y' and c_index[i][j] != 'N':
                c_index[i][j] = int(c_index[i][j])
    num = int(index_max)
    while num > 0:
        for i in range(4, 19):
            for j in range(4, 19):
                if c_index[i][j] == num:
                    c_list[i][j] = 'Y'
        for k in range(4, 19):
            for l in range(4, 19):
                chessmap[num - 1][k][l] = c_list[k][l]
        num = num - 1
    return chessmap


def play_chess(screen, chessmap):
    k = -1
    k_max = len(chessmap) - 1
    while True:
        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    x, y = event.pos[0], event.pos[1]
                    if 640 < x < 700 and 290 < y < 320 and k > 0:
                        k -= 1
                        draw_chessboard_with_chessman(chessmap[k], screen)
                        play_chess_sound.play(0)
                    if 720 < x < 780 and 290 < y < 320 and k < k_max:
                        k += 1
                        draw_chessboard_with_chessman(chessmap[k], screen)
                        play_chess_sound.play(0)
                    choose_button(x, y)
        pygame.display.update()


def pop_window(screen, color):
    """弹出胜利的界面

    """
    if not color:
        pygame.draw.rect(screen, RED, [110, 230, 400, 160], 5)
        s_font = pygame.font.Font('font1.ttf', 80)
        text1 = s_font.render("黑棋胜利！", True, RED)
        screen.blit(text1, (120, 270))
    elif color:
        pygame.draw.rect(screen, RED, [110, 230, 400, 160], 5)
        s_font = pygame.font.Font('font1.ttf', 80)
        text1 = s_font.render("白棋胜利！", True, RED)
        screen.blit(text1, (120, 270))


def tip(screen, chesslist, color, choose, win, wincolor, i1, j1, i2, j2, chessindex, index):
    """显示一些提示

    当前是什么模式，轮到谁落子，谁赢了
    """
    s_font = pygame.font.Font('font.ttf', 40)
    text1 = s_font.render("黑棋落子", True, button)
    text2 = s_font.render("白棋落子", True, button)
    s_font1 = pygame.font.Font('font1.ttf', 30)
    text3 = s_font1.render("人人对战", True, button, (100, 100, 100))
    text4 = s_font1.render("人机对战", True, button, (100, 100, 100))
    draw_chessboard_with_chessman(chesslist, screen)
    if win:
        pop_window(screen, wincolor)
        choose_save(screen, chesslist, chessindex, index)
    if not color:
        screen.blit(text1, (630, 140))
    else:
        screen.blit(text2, (630, 140))
    if choose:
        screen.blit(text3, (650, 20))
        pygame.draw.rect(screen, button, [(i1 - 4) * 40 + 15, (j1 - 4) * 40 + 15, 30, 30], 3)
    else:
        screen.blit(text4, (650, 80))
        pygame.draw.rect(screen, button, [(i1 - 4) * 40 + 15, (j1 - 4) * 40 + 15, 30, 30], 3)
        pygame.draw.rect(screen, button, [(i2 - 4) * 40 + 15, (j2 - 4) * 40 + 15, 30, 30], 3)


def get_score(chesslist, i, j, score):
    """计算棋盘每一个点的得分，将棋盘横竖左右任意长连的五个棋子构成一个列表。共有15*15*4个五元组。人机
    1. 若五元组为空：score += 7
    2. 若五元组为1黑，其余为空：score += 35
    3. 若五元组为2黑，其余为空：score += 800
    4. 若五元组为3黑，其余为空：score += 15000
    5. 若五元组为4黑，其余为空：score += 800000
    6. 若五元组为1白，其余为空：score += 15
    7. 若五元组为2白，其余为空：score += 400
    8. 若五元组为3白，其余为空：score += 1800
    9. 若五元组为4白，其余为空：score += 100000
    10.若五元组既有黑又有白：score += 0

    """
    you_tuple = [0 for i in range(5)]
    xia_tuple = [0 for i in range(5)]
    youxia_tuple = [0 for i in range(5)]
    zuoxia_tuple = [0 for i in range(5)]
    for k in range(5):
        you_tuple[k] = chesslist[i + k][j]
        xia_tuple[k] = chesslist[i][j + k]
        youxia_tuple[k] = chesslist[i + k][j + k]
        zuoxia_tuple[k] = chesslist[i - k][j + k]

    you_black = you_tuple.count(1)
    you_white = you_tuple.count(0)
    you_blank = you_tuple.count('Y')

    xia_black = xia_tuple.count(1)
    xia_white = xia_tuple.count(0)
    xia_blank = xia_tuple.count('Y')

    youxia_black = youxia_tuple.count(1)
    youxia_white = youxia_tuple.count(0)
    youxia_blank = youxia_tuple.count('Y')

    zuoxia_black = zuoxia_tuple.count(1)
    zuoxia_white = zuoxia_tuple.count(0)
    zuoxia_blank = zuoxia_tuple.count('Y')

    if you_blank == 5:
        for k in range(5):
            score[i + k][j] += 7
    if xia_blank == 5:
        for k in range(5):
            score[i][j + k] += 7
    if youxia_blank == 5:
        for k in range(5):
            score[i + k][j + k] += 7
    if zuoxia_blank == 5:
        for k in range(5):
            score[i - k][j + k] += 7

    if you_black == 1 and you_blank == 4:
        for k in range(5):
            score[i + k][j] += 35
    if xia_black == 1 and xia_blank == 4:
        for k in range(5):
            score[i][j + k] += 35
    if youxia_black == 1 and youxia_blank == 4:
        for k in range(5):
            score[i + k][j + k] += 35
    if zuoxia_black == 1 and zuoxia_blank == 4:
        for k in range(5):
            score[i - k][j + k] += 35

    if you_black == 2 and you_blank == 3:
        for k in range(5):
            score[i + k][j] += 800
    if xia_black == 2 and xia_blank == 3:
        for k in range(5):
            score[i][j + k] += 800
    if youxia_black == 2 and youxia_blank == 3:
        for k in range(5):
            score[i + k][j + k] += 800
    if zuoxia_black == 2 and zuoxia_blank == 3:
        for k in range(5):
            score[i - k][j + k] += 800

    if you_black == 3 and you_blank == 2:
        for k in range(5):
            score[i + k][j] += 15000
    if xia_black == 3 and xia_blank == 2:
        for k in range(5):
            score[i][j + k] += 15000
    if youxia_black == 3 and youxia_blank == 2:
        for k in range(5):
            score[i + k][j + k] += 15000
    if zuoxia_black == 3 and zuoxia_blank == 2:
        for k in range(5):
            score[i - k][j + k] += 15000

    if you_black == 4 and you_blank == 1:
        for k in range(5):
            score[i + k][j] += 800000
    if xia_black == 4 and xia_blank == 1:
        for k in range(5):
            score[i][j + k] += 800000
    if youxia_black == 4 and youxia_blank == 1:
        for k in range(5):
            score[i + k][j + k] += 800000
    if zuoxia_black == 4 and zuoxia_blank == 1:
        for k in range(5):
            score[i - k][j + k] += 800000

    if you_white == 1 and you_blank == 4:
        for k in range(5):
            score[i + k][j] += 15
    if xia_white == 1 and xia_blank == 4:
        for k in range(5):
            score[i][j + k] += 15
    if youxia_white == 1 and youxia_blank == 4:
        for k in range(5):
            score[i + k][j + k] += 15
    if zuoxia_white == 1 and zuoxia_blank == 4:
        for k in range(5):
            score[i - k][j + k] += 15

    if you_white == 2 and you_blank == 3:
        for k in range(5):
            score[i + k][j] += 400
    if xia_white == 2 and xia_blank == 3:
        for k in range(5):
            score[i][j + k] += 400
    if youxia_white == 2 and youxia_blank == 3:
        for k in range(5):
            score[i + k][j + k] += 400
    if zuoxia_white == 2 and zuoxia_blank == 3:
        for k in range(5):
            score[i - k][j + k] += 400

    if you_white == 3 and you_blank == 2:
        for k in range(5):
            score[i + k][j] += 1800
    if xia_white == 3 and xia_blank == 2:
        for k in range(5):
            score[i][j + k] += 1800
    if youxia_white == 3 and youxia_blank == 2:
        for k in range(5):
            score[i + k][j + k] += 1800
    if zuoxia_white == 3 and zuoxia_blank == 2:
        for k in range(5):
            score[i - k][j + k] += 1800

    if you_white == 4 and you_blank == 1:
        for k in range(5):
            score[i + k][j] += 100000
    if xia_white == 4 and xia_blank == 1:
        for k in range(5):
            score[i][j + k] += 100000
    if youxia_white == 4 and youxia_blank == 1:
        for k in range(5):
            score[i + k][j + k] += 100000
    if zuoxia_white == 4 and zuoxia_blank == 1:
        for k in range(5):
            score[i - k][j + k] += 100000
    return score


def max_score(chesslist, scorelist):
    """求出得分最高的点

    筛选出已经落子的位置，未落子部分最大值
    """
    mintemp = 0
    a = []
    for i in range(len(scorelist[:][0])):
        for j in range(len(scorelist)):
            if chesslist[i][j] == 'Y' and scorelist[i][j] != [] and scorelist[i][j] > mintemp:
                mintemp = scorelist[i][j]
                a = [i, j]
    return a


def win(lst):
    """判断是否胜利

    """
    for i in range(4, 19):
        for j in range(4, 19):
            if lst[i][j] == lst[i + 1][j] == lst[i + 2][j] == lst[i + 3][j] == lst[i + 4][j] == 1 or \
                    lst[i][j] == lst[i + 1][j] == lst[i + 2][j] == lst[i + 3][j] == lst[i + 4][j] == 0:
                return True
            elif lst[i][j] == lst[i][j + 1] == lst[i][j + 2] == lst[i][j + 3] == lst[i][j + 4] == 1 or \
                    lst[i][j] == lst[i][j + 1] == lst[i][j + 2] == lst[i][j + 3] == lst[i][j + 4] == 0:
                return True
    for i in range(4, 19):
        for j in range(4, 19):
            if lst[i][j] == lst[i + 1][j + 1] == lst[i + 2][j + 2] == lst[i + 3][j + 3] == lst[i + 4][j + 4] == 1 or \
                    lst[i][j] == lst[i + 1][j + 1] == lst[i + 2][j + 2] == lst[i + 3][j + 3] == lst[i + 4][j + 4] == 0:
                return True
    for i in range(4, 19):
        for j in range(4, 19):
            if lst[i][j] == lst[i - 1][j + 1] == lst[i - 2][j + 2] == lst[i - 3][j + 3] == lst[i - 4][j + 4] == 1 or \
                    lst[i][j] == lst[i - 1][j + 1] == lst[i - 2][j + 2] == lst[i - 3][j + 3] == lst[i - 4][j + 4] == 0:
                return True
    return False


def key_control(screen, mode):
    """用于接收用户鼠标的信息

    """
    global running, i_temp1, j_temp1, i_temp2, j_temp2, order, wincolor, choose_turn_result, index, load, chessindex, \
        repent
    if order:
        color = 0
    else:
        color = 1
    tip(screen, lst, color, mode, win(lst), wincolor, i_temp1, j_temp1, i_temp2, j_temp2, chessindex, index)
    if choose_turn_result:
        lst[11][11] = color
        draw_chessman(8, 8, screen, color)
        order = not order
        choose_turn_result = not choose_turn_result
        chessindex[11][11] = index
        index += 1
    for event in pygame.event.get():
        if event.type == MOUSEBUTTONDOWN:
            # 按左键
            if event.button == 1:
                x, y = event.pos[0], event.pos[1]
                for i in range(4, 19):
                    for j in range(4, 19):
                        if ((i-4) * 40 + 15) < x < ((i-4) * 40 + 55) and ((j-4) * 40 + 15) < y < ((j-4) * 40 + 55) and \
                                lst[i][j] == 'Y' and running and not choose_turn_result:
                            repent = True
                            draw_chessman(i, j, screen, color)
                            play_chess_sound.play(0)
                            i_temp1 = i
                            j_temp1 = j
                            lst[i][j] = color
                            wincolor = color
                            chessindex[i][j] = index
                            index += 1
                            if win(lst):
                                victor_sound.play(0)
                                running = False
                            if mode and running:
                                order = not order
                            if not mode and running:
                                score = [[0 for _ in range(23)] for _ in range(23)]
                                for i in range(4, 19):
                                    for j in range(4, 19):
                                        get_score(lst, i, j, score)
                                a = max_score(lst, score)
                                repent = True
                                draw_chessman(a[0], a[1], screen, int(not color))
                                play_chess_sound.play(0)
                                lst[a[0]][a[1]] = int(not color)
                                i_temp2 = a[0]
                                j_temp2 = a[1]
                                wincolor = int(not color)
                                chessindex[a[0]][a[1]] = index
                                index += 1

                            if win(lst) and running:
                                victor_sound.play(0)
                                running = False
                # 如果点击悔棋
                if 650 < x < 730 and 440 < y < 490 and running and repent:
                    if not mode:
                        lst[i_temp1][j_temp1] = 'Y'
                        lst[i_temp2][j_temp2] = 'Y'
                        repent = False
                    elif mode:
                        lst[i_temp1][j_temp1] = 'Y'
                        order = not order
                        repent = False
                    draw_chessboard_with_chessman(lst, screen)
                choose_button(x, y)
        elif event.type == QUIT:
            pygame.quit()
            sys.exit()


def main():
    global background, checkerboard, button, order, lst, score, running, background_jpg, wincolor, i_temp1, j_temp1, \
        i_temp2, j_temp2, choose_turn_result, index, chessindex, load, repent, i_temp3, j_temp3
    pygame.init()
    screen = pygame.display.set_mode((800, 624))
    background_jpg = pygame.image.load("./wuziqi/Background.jpg")
    screen.fill(background)
    screen.blit(background_jpg, (0, 0))
    # order = False时黑棋先手
    order = True
    # 允许落子
    running = True
    # 不许载入棋谱
    load = False
    # 可以悔棋
    repent = True
    # 赢棋的颜色未定
    wincolor = 'Y'
    chessindex = [['N' for _ in range(23)] for _ in range(23)]
    index = 0
    i_temp1 = j_temp1 = i_temp2 = j_temp2 = i_temp3 = j_temp3 = 0

    lst = [['N' for _ in range(23)] for _ in range(23)]
    for i in range(4, 19):
        for j in range(4, 19):
            lst[i][j] = 'Y'
    draw_chessboard(screen)
    pygame.display.update()
    # 选择电脑先手还是玩家先手
    choose_turn_result = 0
    # 选择人人还是人机
    mode, load = choose_mode()
    if not mode:
        choose_turn_result = choose_turn(screen)
    if load:
        try:
            c_map = load_chess()
            play_chess(screen, c_map)
        except:
            main()
        else:
            print("Open Succeeded!")
    while True:
        key_control(screen, mode)
        pygame.display.update()


if __name__ == "__main__":
    main()
